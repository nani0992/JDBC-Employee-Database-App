# Java JDBC Employee Database App

## Objective
Connect to MySQL Database using JDBC and perform CRUD operations.

## Tools
- Java
- MySQL
- JDBC Driver
- VS Code

## Features
- Add Employee
- View Employees
- Update Employee
- Delete Employee

## How to Run
1. Import the SQL file to create the database and table.
2. Update database URL, username, and password in `DBConnection.java`.
3. Compile and run `Main.java`.

## DB Setup
Use the `setup.sql` script to create the database and table.

## Author
Submitted as part of the JDBC learning task.
