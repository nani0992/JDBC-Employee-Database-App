import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EmployeeDAO dao = new EmployeeDAO();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Add Employee\n2. View All\n3. Update\n4. Delete\n5. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    sc.nextLine();
                    String name = sc.nextLine();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    System.out.print("Department: ");
                    sc.nextLine();
                    String dept = sc.nextLine();
                    dao.addEmployee(new Employee(name, age, dept));
                    break;
                case 2:
                    List<Employee> list = dao.getAllEmployees();
                    for (Employee e : list)
                        System.out.println(e.getId() + " " + e.getName() + " " + e.getAge() + " " + e.getDepartment());
                    break;
                case 3:
                    System.out.print("ID to update: ");
                    int uid = sc.nextInt();
                    System.out.print("New Name: ");
                    sc.nextLine();
                    String uname = sc.nextLine();
                    System.out.print("New Age: ");
                    int uage = sc.nextInt();
                    System.out.print("New Department: ");
                    sc.nextLine();
                    String udept = sc.nextLine();
                    dao.updateEmployee(new Employee(uid, uname, uage, udept));
                    break;
                case 4:
                    System.out.print("ID to delete: ");
                    int did = sc.nextInt();
                    dao.deleteEmployee(did);
                    break;
                case 5:
                    sc.close();
                    return;
            }
        }
    }
}
